package com.analistapro.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private static final String SITE = "https://oanalistapro.github.io/ANALISTA-PRO.github.io/";
    private FirebaseAuth auth;
    private CredentialManager credentialManager;
    private WebView web;
    private LinearLayout loginPanel;
    private TextView status;
    private String pendingGoogleToken;
    private boolean pageReady = false;
    private boolean loginRunning = false;
    private final Executor mainExecutor = command -> runOnUiThread(command);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        auth = FirebaseAuth.getInstance();
        credentialManager = CredentialManager.create(this);
        showLoginPanel();
        if (auth.getCurrentUser() != null) {
            // A sessão nativa é persistente. A WebView também preserva a sessão Firebase web.
            openApp();
        }
    }

    private void showLoginPanel() {
        loginPanel = new LinearLayout(this);
        loginPanel.setOrientation(LinearLayout.VERTICAL);
        loginPanel.setGravity(Gravity.CENTER);
        loginPanel.setPadding(32,32,32,32);
        loginPanel.setBackgroundColor(Color.rgb(7,12,23));
        TextView title = new TextView(this);
        title.setText("ANALISTA PRO"); title.setTextColor(Color.WHITE);
        title.setTextSize(26); title.setGravity(Gravity.CENTER);
        loginPanel.addView(title);
        status = new TextView(this);
        status.setText("Entre com sua conta Google para continuar.");
        status.setTextColor(Color.WHITE); status.setGravity(Gravity.CENTER);
        status.setPadding(0,24,0,24);
        loginPanel.addView(status);
        Button btn = new Button(this);
        btn.setText("Entrar com Google");
        btn.setOnClickListener(v -> startGoogleLogin());
        loginPanel.addView(btn);
        setContentView(loginPanel);
    }

    private void startGoogleLogin() {
        if (loginRunning) return;
        loginRunning = true;
        if (status != null) status.setText("Selecione sua conta Google...");
        GetGoogleIdOption option = new GetGoogleIdOption.Builder()
            .setServerClientId(getString(R.string.default_web_client_id))
            .setFilterByAuthorizedAccounts(false)
            .setAutoSelectEnabled(false)
            .build();
        GetCredentialRequest request = new GetCredentialRequest.Builder()
            .addCredentialOption(option).build();
        credentialManager.getCredentialAsync(this, request, new CancellationSignal(),
            mainExecutor, new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse result) {
                    try {
                        Credential c = result.getCredential();
                        if (!(c instanceof CustomCredential) ||
                            !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType()))
                            throw new IllegalStateException("Conta Google não reconhecida");
                        String googleToken = GoogleIdTokenCredential.createFrom(c.getData()).getIdToken();
                        auth.signInWithCredential(GoogleAuthProvider.getCredential(googleToken, null))
                            .addOnSuccessListener(MainActivity.this, r -> {
                                loginRunning = false;
                                pendingGoogleToken = googleToken;
                                if (web == null) openApp();
                                else deliverTokenToWeb();
                            })
                            .addOnFailureListener(MainActivity.this, e -> failLogin(e.getMessage()));
                    } catch (Exception e) { failLogin(e.getMessage()); }
                }
                @Override public void onError(GetCredentialException e) { failLogin(e.getMessage()); }
            });
    }

    private void failLogin(String error) {
        loginRunning = false;
        if (web == null && status != null) status.setText("Falha no login: " + error);
        else Toast.makeText(this,"Falha no login Google: " + error,Toast.LENGTH_LONG).show();
    }

    private boolean trusted(Uri uri) {
        return "https".equalsIgnoreCase(uri.getScheme())
            && "oanalistapro.github.io".equalsIgnoreCase(uri.getHost())
            && uri.getPath() != null && uri.getPath().startsWith("/ANALISTA-PRO.github.io/");
    }

    private void openApp() {
        if (web != null) { setContentView(web); deliverTokenToWeb(); return; }
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " AnalistaProNative/1");
        CookieManager.getInstance().setAcceptCookie(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("analistapro".equals(uri.getScheme()) && "login".equals(uri.getHost())) {
                    startGoogleLogin(); return true;
                }
                if (trusted(uri)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception ignored) {}
                return true;
            }
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap favicon) {
                pageReady=false;
            }
            @Override public void onPageFinished(WebView view,String url) {
                pageReady = trusted(Uri.parse(url));
                deliverTokenToWeb();
            }
        });
        setContentView(web);
        web.loadUrl(SITE);
    }

    private void deliverTokenToWeb() {
        if (web == null || !pageReady || pendingGoogleToken == null) return;
        if (!trusted(Uri.parse(web.getUrl() == null ? "" : web.getUrl()))) return;
        String token = pendingGoogleToken;
        // Entregar somente à origem do app e somente no documento principal.
        String js = "window.__analistaNativeGoogleToken && window.__analistaNativeGoogleToken(" +
            org.json.JSONObject.quote(token) + ");";
        web.evaluateJavascript(js, null);
        pendingGoogleToken = null;
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
